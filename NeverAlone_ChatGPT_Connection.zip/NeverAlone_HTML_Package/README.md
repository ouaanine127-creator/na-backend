# Never Alone — connect real AI chat

## Important distinction
This connects the app to the OpenAI API (or another compatible provider), not to this exact ChatGPT app conversation or your ChatGPT account session. API usage may require a separately billed API account.

## 1. Deploy the backend
The browser-based HTML UI cannot safely contain a private API key. Deploy the `backend/` folder to a server you control.

Requirements: Python 3.11+.

```bash
cd backend
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate
pip install -r requirements.txt
```

Set environment variables on the server (do not put a real key in the HTML):

- `AI_API_KEY` = your API provider key
- `AI_MODEL` = a model available to your account, e.g. `gpt-4o-mini`
- Optional `AI_BASE_URL` = only for a compatible alternative provider

Run locally for a test:

```bash
uvicorn app:app --host 127.0.0.1 --port 8000
```

The backend endpoint will be `http://127.0.0.1:8000/chat` for local testing. A deployed app needs a public HTTPS backend URL; do not use `127.0.0.1` from another device. Configure CORS and authentication appropriately before public deployment, and add rate limiting to prevent abuse.

## 2. Connect the HTML UI
Open `index.html`, expand **AI connection settings**, enter your backend `/chat` URL, and press **Save**. Then send a message. The app sends the current conversation history to the backend and displays the provider's actual response.

## Limitations
- The included HTML interface runs in a browser if opened as HTML; it is not a native Android/Windows app.
- Speech recognition and speech synthesis depend on browser/device support.
- No API key, deployed backend, or live connection is included in this ZIP. You must supply and configure these yourself.
